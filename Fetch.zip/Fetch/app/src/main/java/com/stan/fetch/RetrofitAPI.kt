package com.stan.fetch

import retrofit2.Call
import retrofit2.http.GET

interface RetrofitAPI {
    @GET("/hiring.json")
    fun getListItems() : Call<List<Items>>
}