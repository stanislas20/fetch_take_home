package com.stan.fetch

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.stan.fetch.databinding.ListItemsBinding

class ListAdapter(var listItems: List<Items>) :
    RecyclerView.Adapter<ListAdapter.ListViewHolder>() {

    fun setItems(items: List<Items>) {
        this.listItems = items
        notifyDataSetChanged()
    }


    inner class ListViewHolder(val adapterBinding: ListItemsBinding) :
        RecyclerView.ViewHolder(adapterBinding.root) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val binding = ListItemsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return listItems.size
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {

        holder.adapterBinding.textViewId.text = "id :  ${listItems[position].id.toString()}"
        holder.adapterBinding.textViewListId.text =
            "listId: ${listItems[position].listId.toString()}"
        holder.adapterBinding.textViewName.text = listItems[position].name
    }


}
