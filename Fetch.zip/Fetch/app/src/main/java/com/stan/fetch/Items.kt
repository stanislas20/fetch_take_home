package com.stan.fetch

data class Items(
    val id: Int,
    val listId: Int,
    val name: String?
)
