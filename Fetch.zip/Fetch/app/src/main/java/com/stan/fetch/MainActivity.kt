package com.stan.fetch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.stan.fetch.databinding.ActivityMainBinding
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private val baseURL = "https://fetch-hiring.s3.amazonaws.com"

    lateinit var mainBinding: ActivityMainBinding

    var listItems = ArrayList<Items>()

    lateinit var adapter: ListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainBinding = ActivityMainBinding.inflate(layoutInflater)
        val view = mainBinding.root
        setContentView(view)

        mainBinding.rvRecyclerView.layoutManager = LinearLayoutManager(this)


        displayListItems()
    }

    private fun displayListItems() {
        val retrofit = Retrofit.Builder()
            .baseUrl(baseURL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val retrofitAPI = retrofit.create(RetrofitAPI::class.java)
        // accessing the function getListItems in the RetrofitAPI interface
        val call: Call<List<Items>> = retrofitAPI.getListItems()

        call.enqueue(object : Callback<List<Items>> {

            override fun onResponse(call: Call<List<Items>>, response: Response<List<Items>>) {
                if (response.isSuccessful) {
                    mainBinding.progressBar.isVisible = false
                    mainBinding.rvRecyclerView.isVisible = true
                    listItems = response.body() as ArrayList<Items>
                    adapter = ListAdapter(listItems)
                    mainBinding.rvRecyclerView.adapter = adapter

                    //Calling the method below to organize the items in the recyclerView
                    organisedItems(listItems)

                }
            }

            override fun onFailure(call: Call<List<Items>>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })
    }

    // function below takes care of organizing items in the recyclerView
    private fun organisedItems(items: List<Items>) {
        // case: Filter out any items where "name" is blank or null
        val itemsFiltered = items.filter { it.name?.isNotBlank() == true }

        // case: group items by listId
        val itemsGroupedByListId = itemsFiltered.groupBy { it.listId }

        // case: Sort the results first by "listId" then by "name" when displaying
        val listIdAndNameSorted = itemsGroupedByListId.values.flatten()
            .sortedWith(compareBy({ it.listId }, { it.name }))
        // Notify the adapter after all the items are sorted
        adapter.setItems(listIdAndNameSorted)
    }
}


